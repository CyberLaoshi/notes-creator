import { useState } from "react";

interface Props {
  onAddItem: (item: string[]) => void;
}

function CreateNewNote({ onAddItem }: Props) {
  const [heading, setHeading] = useState("");
  const [name, setName] = useState("");
  const [timing, setTiming] = useState("");
  const [content, setContent] = useState("");
  return (
    <>
      <h2>Новая запись</h2>
      <label htmlFor="heading">
        Заголовок
        <input
          type="text"
          id="heading"
          name="headingInfo"
          value={heading}
          onChange={(event) => setHeading(event.target.value)}
        />
      </label>

      <label htmlFor="date">
        Дата
        <input
          id="date"
          type="text"
          value={timing}
          onChange={(event) => setTiming(event.target.value)}
        />
      </label>

      <br />
      <input
        type="text"
        value={name}
        onChange={(event) => setName(event.target.value)}
      />
      <br />
      <textarea
        name="postContent"
        rows={5}
        cols={80}
        value={content}
        onChange={(event) => setContent(event.target.value)}
      />
      <br />
      <button
        onClick={() => {
          setName("");
          setTiming("");
          setContent("");
          setHeading("");
          onAddItem([heading, name, timing, content]); // сохранить в JSON https://react.dev/reference/react-dom/components/textarea
        }}
      >
        Создать
      </button>
    </>
  );
}

export default CreateNewNote;
